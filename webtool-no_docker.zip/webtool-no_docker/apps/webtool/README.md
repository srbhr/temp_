# FNBr Webtool
WebTool is an annotation and database management application
developed by [FrameNet Brasil Project](http://www.ufjf.br/framenetbr-eng/), which can be accessed using any web browser,
without the need to install any additional software. Webtool handles multilingual framenets and constructicons.

## License

GNU GPLv3 - See the [COPYING](COPYING) file for license rights and limitations.