<?php

use fnbr\auth\models as models;

class MainController extends \MController {

    public function init(){
    }

    public function main() {
        $this->render();
    }

}