<?php
namespace Mesh\Element\Node;

class TypeNode extends Node
{

}

