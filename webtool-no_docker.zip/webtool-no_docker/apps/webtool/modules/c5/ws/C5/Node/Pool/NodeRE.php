<?php
namespace Mesh\Node\Pool;

use Mesh\Element\Node\NodePool;

class NodeRE extends NodePool
{
}

