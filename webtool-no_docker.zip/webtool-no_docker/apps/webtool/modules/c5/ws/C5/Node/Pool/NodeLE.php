<?php
namespace Mesh\Node\Pool;

use Mesh\Element\Node\NodePool;

class NodeLE extends NodePool
{

}

