<?php
return [
    'c5' => [
        'driver' => 'pdo_mysql',
        'user' => '',
        'password' => '',
        'host' => '127.0.0.1',
        'port' => '3306',
        'dbname' => ''
    ],

];