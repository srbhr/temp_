<?php
namespace Mesh\Node\Pool;

use Mesh\Element\Node\NodePool;

class NodeDE extends NodePool
{
}

